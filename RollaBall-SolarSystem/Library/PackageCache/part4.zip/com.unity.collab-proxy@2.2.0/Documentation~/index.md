# About Version Control

The Version Control package provides an in-editor interface for teams to work with Unity Version Control (Unity VCS).

## Unity Version Control

It is a free Unity plug-in that gives you the ability to use Unity VCS, a leading version control solution, directly in Unity. Get started with [Unity VCS](QuickStartGuide.md).
