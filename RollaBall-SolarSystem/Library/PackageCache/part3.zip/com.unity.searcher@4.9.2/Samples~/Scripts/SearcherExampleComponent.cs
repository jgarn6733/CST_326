using System;
using UnityEngine;

namespace UnityEditor.Searcher
{
    public class SearcherExampleComponent : MonoBehaviour { }
}
