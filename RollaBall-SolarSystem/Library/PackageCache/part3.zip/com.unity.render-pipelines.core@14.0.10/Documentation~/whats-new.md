# What's new in SRP Core

This section contains information about changes to SRP Core. Each page contains a list of new features and, if relevant, a list of improvements and a list of resolved issues.

The list of pages is as follows:

- [12](whats-new-12.md)
- [13](whats-new-13.md)
