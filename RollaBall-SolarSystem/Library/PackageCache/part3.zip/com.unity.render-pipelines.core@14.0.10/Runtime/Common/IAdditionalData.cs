
namespace UnityEngine.Rendering
{
    /// <summary>
    /// Interface to identify additional data components
    /// </summary>
    public interface IAdditionalData
    {
    }
}
