namespace UnityEngine.Rendering
{
    internal enum CoreProfileId
    {
        BlitTextureInPotAtlas,
        APVCellStreamingUpdate,
        APVScenarioBlendingUpdate,
    }
}
