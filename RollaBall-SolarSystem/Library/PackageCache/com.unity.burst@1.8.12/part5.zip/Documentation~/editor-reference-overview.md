# Editor reference

Explore the specific Burst Editor features.

|**Topic**|**Description**|
|---|---|
|[Burst menu](editor-burst-menu.md)|Use the Burst menu to control the Burst settings in your project.|
|[Burst Inspector](editor-burst-inspector.md)|Use the Burst Inspector to see the jobs and Burst compiled targets in your project.|

## Additional resources

* [Building your project](building-projects.md)