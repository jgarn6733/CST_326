# Feature comparison table

For an overview of the features supported in the Universal Render Pipeline (URP) compared to the other Unity render pipelines, refer to the page [Render pipeline feature comparison](https://docs.unity3d.com/2022.2/Documentation/Manual/render-pipelines-feature-comparison.html).